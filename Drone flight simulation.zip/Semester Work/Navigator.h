#ifndef NAVIGATOR_H
#define NAVIGATOR_H
#include "Drone.h"

class Navigator :
    public Drone
{
private:
    string gpsType;
public:
    Navigator(int id, int velocity, int batteryCharge, int batteryDischarge, int currentX, int currentY, int destinationX, int destinationY, string gpsType);

    //Getters and Setters
    string getGpsType() const;
    void setGpsType(string gpsType);

    //Main methods
    void info()override;
};

#endif