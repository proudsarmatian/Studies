#include "Navigator.h"

Navigator::Navigator(int id, int velocity, int batteryCharge, int batteryDischarge, int currentX, int currentY, int destinationX, int destinationY, string gpsType) :
    Drone(id, velocity, batteryCharge, batteryDischarge, currentX, currentY, destinationX, destinationY)
{
    this->setType("Navigator");
    this->setGpsType(gpsType);
}

string Navigator::getGpsType() const
{
    return gpsType;
}

void Navigator::setGpsType(string gpsType)
{
    this->gpsType = gpsType;
}

void Navigator::info()
{
    HANDLE color = GetStdHandle(STD_OUTPUT_HANDLE);

    SetConsoleTextAttribute(color, 2);
    cout << getType(); 
    SetConsoleTextAttribute(color, 7);
    cout << " drone #" << getId() << " is currently at: X = " << getCurrentY() << ",  Y = " << getCurrentX() << "  | ";
    cout << "Its destination is: X = " << getDestinationY() << ",  Y = " << getDestinationX() << "    \t" << endl;
    cout << "Battery charge left: " << getBatteryCharge() << "    \t";
    if (this->getIsOnline()) {
        cout << " \t| ";
        SetConsoleTextAttribute(color, 2);
        cout << "Drone is online.                                   " << endl;
    }
    else {
        cout << " \t| ";
        SetConsoleTextAttribute(color, 12);
        cout << "Drone is offline.                                   " << endl;
    }
    SetConsoleTextAttribute(color, 3);
    cout << "Status: "; 
    SetConsoleTextAttribute(color, 7);
    cout << printStatus() << "                                   " << endl;
    cout << "---------------------------------" << endl;
}
