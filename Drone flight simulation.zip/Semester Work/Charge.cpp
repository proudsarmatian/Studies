#include "Charge.h"

Charge::Charge()
{
    currentX = 0;
    currentY = 0;
    state = true;
    amount = 0;
}

Charge::Charge(int x, int y, int amount)
{
    this->setCurrentX(x);
    this->setCurrentY(y);
    this->setState(true);
    this->setAmount(amount);
}

int Charge::getCurrentX() const
{
    return currentX;
}

void Charge::setCurrentX(int currentX)
{
    if (currentX < FIELD_SIZE - 1 && currentX > 0) {
        this->currentX = currentX;
    }
    else if (currentX > FIELD_SIZE - 1) {
        this->currentX = FIELD_SIZE - 2;
    }
    else {
        this->currentX = 1;
    }
}

int Charge::getCurrentY() const
{
    return currentY;
}

void Charge::setCurrentY(int currentY)
{
    if (currentY >= 0 && currentY <= FIELD_SIZE - 1) { this->currentY = currentY; }
    else if (currentY >= FIELD_SIZE - 1) {
        this->currentY = FIELD_SIZE - 1;
    }
    else {
        this->currentY = 0;
    }
}

bool Charge::getState() const
{
    return state;
}

void Charge::setState(bool state)
{
    this->state = state;
}

int Charge::getAmount() const
{
    return amount;
}

void Charge::setAmount(int amount)
{
    if (amount < 0) {
        this->amount = 0;
    }
    else {
        this->amount = amount;
    }
}

int Charge::generate()
{
    int n = rand() % (FIELD_SIZE - 2) + 1;
    return n;
}

void Charge::generateAmount()
{
    int n = rand() % 10 + 0;
    this->setAmount(n);
}

