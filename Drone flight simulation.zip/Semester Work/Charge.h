#ifndef CHARGE_H
#define CHARGE_H

#include "Drone.h"

class Charge
{
private:
    int currentX;
    int currentY;
    bool state;
    int amount;
public:
    Charge();
    Charge(int x, int y, int amount);

    //Getters and Setters
    int getCurrentX() const;
    void setCurrentX(int currentX);

    int getCurrentY() const;
    void setCurrentY(int currentY);

    bool getState() const;
    void setState(bool state);

    int getAmount() const;
    void setAmount(int amount);

    //Main methods
    int generate();
    //generates random amount of battery charge
    void generateAmount();
};

#endif