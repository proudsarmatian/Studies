#ifndef DRONE_H
#define DRONE_H

#include <iostream>
#include <string>
#include <windows.h>

using namespace std;

//Constants
const int FIELD_SIZE = 40;
const char FIELD_DOT = ' ';

const int DRONES_NUM = 4;
const int AMOUNT_OF_BOMBS = 50;
const int AMOUNT_OF_CHARGE = 500;
const int AMOUNT_OF_CARGO = 8;

const int VELOCITY = 2;
const int VELOCITY_CARRY = 1;
const int CARRY = 20;
const int DESTINATION_X = 0;

const int BATTERY_CHARGE = 40;
const int BATTERY_CHARGE_CARRY = 60;
const int BATTERY_DISCHARGE = 1;
const int BATTERY_DISCHARGE_CARRY = 2;

//Enum for keeping status states simply stored
enum Status { Spawned = 1, Flying = 2, Reached = 3, RanOut = 4, Falling = 5, Fell = 6, Crashed = 7};

class Drone
{
private:
    //Main
    int id;
    string type;
    int velocity;
    int batteryCharge;
    int currentX;
    int currentY;
    int destinationX;
    int destinationY;

    //Extra
    Status status;
    int batteryDischarge;
    bool isOnline;
public:
    Drone();
    Drone(int id, int velocity, int batteryCharge, int batteryDischarge, int currentX, int currentY, int destinationX, int destinationY);

    //Getters and Setters
    int getId() const;
    void setId(int id);

    string getType() const;
    void setType(string type);

    int getVelocity() const;
    void setVelocity(int velocity);

    int getBatteryCharge() const;
    void setBatteryCharge(int batteryCharge);

    int getBatteryDischarge() const;
    void setBatteryDischarge(int batteryDischarge);

    int getCurrentX() const;
    void setCurrentX(int currentX);

    int getCurrentY() const;
    void setCurrentY(int currentY);

    int getDestinationX() const;
    void setDestinationX(int destinationX);

    int getDestinationY() const;
    void setDestinationY(int destinationY);

    bool getIsOnline() const;
    void setIsOnline(int id);

    Status getStatus() const;
    void setStatus(Status status);

    //Main methods
    virtual void info() = 0;
    void move();

    // Other methods

    //Checks if battery still have any charge
    void batteryCheck();
    //Checks if drone arrived to the destination point
    void arrivalCheck();
    //Checks status
    void statusCheck();
    //Returns string depending on status
    string printStatus();
    //Method for falling drones
    void fall();

    //To allow field call for drone methods
    friend class Field;
};

#endif