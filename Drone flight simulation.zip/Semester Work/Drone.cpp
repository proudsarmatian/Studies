#include "Drone.h"

Drone::Drone()
{
    id = 0;
    type = "unknown";
    velocity = 0;
    batteryCharge = 0;
    batteryDischarge = 0;
    currentX = 0;
    currentY = 0;
    destinationX = 0;
    destinationY = 0;
    isOnline = 1;
}

Drone::Drone(int id, int velocity, int batteryCharge, int batteryDischarge, int currentX, int currentY, int destinationX, int destinationY)
{
    this->setId(id);
    this->setVelocity(velocity);
    this->setBatteryCharge(batteryCharge);
    this->setBatteryDischarge(batteryDischarge);
    this->setCurrentX(currentX);
    this->setCurrentY(currentY);
    this->setDestinationX(destinationX);
    this->setDestinationY(destinationY);
    this->setIsOnline(1);
    this->setStatus(Spawned);
}

int Drone::getId() const
{
    return id;
}

void Drone::setId(int id)
{
    if (id >= 0) { this->id = id; }
    else {
        cout << "Drone's ID is out of range!" << endl;
        exit(1);
    }
}

string Drone::getType() const
{
    return type;
}

void Drone::setType(string type)
{
    this->type = type;
}

int Drone::getVelocity() const
{
    return velocity;
}

void Drone::setVelocity(int velocity)
{
    if (velocity >= 0) { this->velocity = velocity; }
    else {
        cout << "Drone's velocity must be above or equal to 0!" << endl;
        exit(1);
    }
}

int Drone::getBatteryCharge() const
{
    return batteryCharge;
}

void Drone::setBatteryCharge(int batteryCharge)
{
    if (batteryCharge >= 0 && batteryCharge <= BATTERY_CHARGE) { this->batteryCharge = batteryCharge; }
    else if (batteryCharge > BATTERY_CHARGE) {
        this->batteryCharge = BATTERY_CHARGE;
    }
    else {
        this->batteryCharge = 0;
    }
}

int Drone::getCurrentX() const
{
    return currentX;
}

void Drone::setCurrentX(int currentX)
{
    if (currentX < FIELD_SIZE && currentX >= 0) {
        this->currentX = currentX; 
    }
    else if (currentX >= FIELD_SIZE){
        this->currentX = FIELD_SIZE - 1;
    }
    else {
        this->currentX = 0;
    }
}

int Drone::getCurrentY() const
{
    return currentY;
}

void Drone::setCurrentY(int currentY)
{
    if (currentY >= 0 && currentY <= FIELD_SIZE - 1) { this->currentY = currentY; }
    else if (currentY > FIELD_SIZE - 1) {
        this->currentY = FIELD_SIZE - 1;
    }
    else {
        this->currentY = 0;
    }
}

int Drone::getDestinationX() const
{
    return destinationX;
}

void Drone::setDestinationX(int destinationX)
{
    if (destinationX >= 0) { this->destinationX = destinationX; }
    else {
        cout << "Drone's destination X is out of range!" << endl;
        exit(1);
    }
}

int Drone::getDestinationY() const
{
    return destinationY;
}

void Drone::setDestinationY(int destinationY)
{
    if (destinationY >= 0) { this->destinationY = destinationY; }
    else {
        cout << "Drone's destination Y is out of range!" << endl;
        exit(1);
    }
}

int Drone::getBatteryDischarge() const
{
    return batteryDischarge;
}

void Drone::setBatteryDischarge(int batteryDischarge)
{
    if (batteryDischarge >= 0) { this->batteryDischarge = batteryDischarge; }
    else {
        cout << "Drone's battery discharge must be above or equal to 0!" << endl;
        exit(1);
    }
}

bool Drone::getIsOnline() const
{
    return isOnline;
}

void Drone::setIsOnline(int isOnline)
{
    if (isOnline > 0) { this->isOnline = true; }
    else { this->isOnline = false; }
}

Status Drone::getStatus() const
{
    return status;
}

void Drone::setStatus(Status status)
{
    this->status = status;
}

//Min move method
void Drone::move() {
    this->statusCheck(); //Status check
    if (this->getIsOnline()) {
        //If drone is still online, moves it depending on velocity
        for (auto i = 0; i < this->getVelocity(); ++i) {
            if (this->getCurrentX() != this->getDestinationX() || this->getCurrentY() != this->getDestinationY()) {
                if (this->getCurrentY() > this->getDestinationY()) {
                    //If drone is on the right from destintion point
                    if (getCurrentX() == getDestinationX()) {
                        //Horisontal movement only if destination X is reached
                        setCurrentY(getCurrentY() - 1);
                    }
                    else {
                        setCurrentY(getCurrentY() - 1);
                        setCurrentX(getCurrentX() - 1);
                    } 
                }
                //If drone is on the left from destintion point
                else if (this->getCurrentY() < this->getDestinationY()) {
                    if (getCurrentX() == getDestinationX()) {
                        //Horisontal movement only if destination X is reached
                        setCurrentY(getCurrentY() + 1);
                    }
                    else {
                        setCurrentY(getCurrentY() + 1);
                        setCurrentX(getCurrentX() - 1);
                    }
                }
                //If drone is directly below destination point it moves only vertically
                else {
                    setCurrentX(getCurrentX() - 1);
                }
            }
            else
            {
                //If destination reached drone goes offline
                this->setIsOnline(0);
            }
        }
        //Lower the battery charge
        this->setBatteryCharge(getBatteryCharge() - getBatteryDischarge()); 
    }
}

void Drone::fall() {
    setCurrentX(getCurrentX() + 2);

    if (this->getCurrentX() == FIELD_SIZE - 1) {
        this->setStatus(Fell);
    }
}

void Drone::batteryCheck()
{
    if (this->getBatteryCharge() == 0) {
        this->setStatus(RanOut);
    }
}

void Drone::arrivalCheck() {
    if (this->getStatus() != Crashed && this->getBatteryCharge() > 0 && (this->getCurrentX() != this->getDestinationX() || this->getCurrentY() != this->getDestinationY())) {
        this->setStatus(Flying);
    }
    else if (this->getCurrentX() == this->getDestinationX() && this->getCurrentY() == this->getDestinationY()) {
        this->setStatus(Reached);
    }
}

void Drone::statusCheck()
{

    this->batteryCheck();
    this->arrivalCheck();

    if (this->getStatus() == Reached) {
        this->setIsOnline(0);
    }
    if (this->getIsOnline() == false && this->getStatus() != Reached) {
        this->setStatus(Falling);
    }
    if (this->getStatus() == Crashed) {
        this->setIsOnline(0);
    }
    if (this->getStatus() == RanOut) {
        this->setIsOnline(0);
    }
    if (this->getStatus() == Falling) {
        this->fall();
    }
    if (this->getStatus() == Fell) {

    }
}

string Drone::printStatus() {
    string s;
    if (this->getStatus() == 0) {
        s = "unknown...";
    }
    else if (this->getStatus() == 1) {
        s = "Drone spawned";
    }
    else if (this->getStatus() == 2) {
        s = "Drone is flying";
    }
    else if (this->getStatus() == 3) {
        s = "Drone reached its destination point";
    }
    else if (this->getStatus() == 4) {
        s = "Drone ran out of battery charge";
    }
    else if (this->getStatus() == 5) {
        s = "Drone is falling";
    }
    else if (this->getStatus() == 6) {
        s = "Unfortunatelly drone fell";
    }
    else if (this->getStatus() == 7) {
        s = "Unfortunatelly drone crashed";
    }
    return s;
}