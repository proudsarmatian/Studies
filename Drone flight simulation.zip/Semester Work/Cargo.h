#ifndef CARGO_H
#define CARGO_H

#include "Drone.h"

class Cargo
{
private:
	int currentX;
	int currentY;
	bool state;
	int amount;
public:
    Cargo();
    Cargo(int x, int y, int amount);

    //Getters and Setters
    int getCurrentX() const;
    void setCurrentX(int currentX);

    int getCurrentY() const;
    void setCurrentY(int currentY);

    bool getState() const;
    void setState(bool state);

    int getAmount() const;
    void setAmount(int amount);

    //Main methods

    //Starts falling sequence by dropping cargo
    void dropCargo(int x, int y, int amount);
    //Technically cargos "move"
    void fall();

};

#endif