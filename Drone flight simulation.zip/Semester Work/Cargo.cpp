#include "Cargo.h"

Cargo::Cargo()
{
    currentX = 0;
    currentY = 0;
    state = false;
    amount = 0;
}

Cargo::Cargo(int x, int y, int amount)
{
    this->setCurrentX(x);
    this->setCurrentY(y);
    this->setState(false);
    this->setAmount(amount);
}

int Cargo::getCurrentX() const
{
    return currentX;
}

void Cargo::setCurrentX(int currentX)
{
    if (currentX < FIELD_SIZE - 1 && currentX > 0) {
        this->currentX = currentX;
    }
    else if (currentX >= FIELD_SIZE - 1) {
        this->currentX = FIELD_SIZE - 1;
    }
    else {
        this->currentX = 1;
    }
}

int Cargo::getCurrentY() const
{
    return currentY;
}

void Cargo::setCurrentY(int currentY)
{
    if (currentY >= 0 && currentY <= FIELD_SIZE - 1) { this->currentY = currentY; }
    else if (currentY >= FIELD_SIZE - 1) {
        this->currentY = FIELD_SIZE - 1;
    }
    else {
        this->currentY = 0;
    }
}

bool Cargo::getState() const
{
    return state;
}

void Cargo::setState(bool state)
{
    this->state = state;
}

int Cargo::getAmount() const
{
    return amount;
}

void Cargo::setAmount(int amount)
{
    if (amount < 0) {
        this->amount = 0;
    }
    else {
        this->amount = amount;
    }
}

void Cargo::dropCargo(int x, int y, int amount)
{
    this->setCurrentX(x);
    this->setCurrentY(y);
    this->setState(true);
    this->setAmount(amount);
}

void Cargo::fall()
{
    if (this->getState()) {
        setCurrentX(getCurrentX() + 3);

        //When cargo reaches lowest point it goes dormant and can be recall again for another drone
        if (this->getCurrentX() == FIELD_SIZE - 1) {
            this->setState(false);
            this->setAmount(0);
        }
    }
}

