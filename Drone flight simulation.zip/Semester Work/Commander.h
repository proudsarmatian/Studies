#ifndef COMMANDER_H
#define COMMANDER_H
#include "Navigator.h"

class Commander :
    public Navigator
{
private:
    string commandAndControlType;
public:
    Commander(int id, int velocity, int batteryCharge, int batteryDischarge, int currentX, int currentY, int destinationX, int destinationY, string gpsType, string commandAndControlType);

    //Getters and Setters
    string getCommandAndControlType() const;
    void setCommandAndControlType(string commandAndControlType);

    //Main methods
    void info()override;

    //Other methods
    int generate();
};

#endif