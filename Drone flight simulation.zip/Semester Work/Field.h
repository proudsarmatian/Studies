#ifndef FIELD_H
#define FIELD_H

#include <iostream>
#include <string>
#include "Drone.h"
#include "Bomb.h"
#include "Charge.h"
#include "Carrier.h"
#include "Cargo.h"

using namespace std;

class Field
{
    char field[FIELD_SIZE][FIELD_SIZE];
    char map[FIELD_SIZE][FIELD_SIZE];
public:
    Field();

    //Getters and Setters
    char getField(int n, int m) const;
    void setField(int n, int m, char field);

    char getMap(int n, int m) const;
    void setMap(int n, int m, char map);

    //Main methods

    //Printing
    void print();
    void printMap();
    //Updating field
    void refreshField(Drone* hive[], Bomb* bombs, Charge* charge, Cargo* cargo);
    //Updating map
    void updateMap(Drone* hive[], Bomb* bombs, Charge* charge);

    //Cheking stuff

    //If field point is empty
    bool isAvailable(int n, int m);
    //If drones still flying
    bool dronesInFlight(Drone* hive[]);
    //If field size is acceptable and can spawn all amount of entities
    void check();
    //If drones collided with each other or other objects
    void checkCollisions(Drone* hive[], Bomb* bombs, Charge* charge, Cargo* cargo);
    void checkDroneCollisions(Drone* hive[]);
    void checkBombCollisions(Drone* hive[], Bomb* bombs, Cargo* cargo);
    void checkChargeCollisions(Drone* hive[], Charge* charge);
    void checkCargoCollisions(Drone* hive[], Cargo* cargo);

    //Other methods

    //Consider the type of drone to get the right char value for printing
    int droneType(Drone* hive, int n);
    //Sets bombs on the field/map
    void plantBombs(Bomb* bombs);
    //Sets battery chargers on the field/map
    void plantCharge(Charge* charge);
    //Sets falling cargo on the field
    void plantCargo(Cargo* cargo);
};

#endif