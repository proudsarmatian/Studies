#ifndef COMMUNICATOR_H
#define COMMUNICATOR_H
#include "Drone.h"

class Communicator :
    public Drone
{
private:
    int communicationRange;
public:
    Communicator(int id, int velocity, int batteryCharge, int batteryDischarge, int currentX, int currentY, int destinationX, int destinationY, int communicationRange);

    //Getters and Setters
    int getCommunicationRange() const;
    void setCommunicationRange(int communicationRange);

    //Main methods
    void info()override;
};

#endif