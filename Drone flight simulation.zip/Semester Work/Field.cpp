#include "Field.h"

Field::Field() {
    for (auto i = 0; i < FIELD_SIZE; ++i) {
        for (auto j = 0; j < FIELD_SIZE; ++j) {
            setField(i,j, FIELD_DOT);
        }
    }
    for (auto i = 0; i < FIELD_SIZE; ++i) {
        for (auto j = 0; j < FIELD_SIZE; ++j) {
            setMap(i, j, FIELD_DOT);
        }
    }
}

char Field::getField(int n, int m) const
{
    return field[n][m];
}

void Field::setField(int n, int m, char field)
{
    this->field[n][m] = field;
}

char Field::getMap(int n, int m) const
{
    return map[n][m];
}

void Field::setMap(int n, int m, char map)
{
    this->map[n][m] = map;
}


bool Field::isAvailable(int n, int m) {
    return getField(n, m) == FIELD_DOT;
}

void Field::check() {
    if (DRONES_NUM > FIELD_SIZE) {
        cout << "Field if too small!" << endl;
        exit(1);
    }

    //Chacking if we can spawn everyithing
    if (AMOUNT_OF_BOMBS + AMOUNT_OF_CHARGE > FIELD_SIZE * FIELD_SIZE / 100 * 95) {
        cout << "Cant spawn that much of additional objects!" << endl;
        exit(1);
    }
}

void Field::print() {
    HANDLE color = GetStdHandle(STD_OUTPUT_HANDLE);

    for (auto j = 0; j < FIELD_SIZE; ++j) {
        cout << "==";
    }
    cout << endl;
    for (auto i = 0; i < FIELD_SIZE; ++i) {
        for (auto j = 0; j < FIELD_SIZE; ++j) {
            if (getField(i, j) == 118) {
                SetConsoleTextAttribute(color, 10);
                cout << getField(i, j) << " ";
            }
            //Red screen alert when drones are crashing
            else if (getField(i, j) == 'x') {
                system("Color 47");
                cout << getField(i, j) << " ";
                system("Color 07");
            }
            else if (getField(i, j) == 67) {
                SetConsoleTextAttribute(color, 12);
                cout << getField(i, j) << " ";
            }
            else if (getField(i, j) == 61) {
                SetConsoleTextAttribute(color, 9);
                cout << getField(i, j) << " ";
            }
            else if (getField(i, j) == 85 || getField(i, j) == 86) {
                SetConsoleTextAttribute(color, 11);
                cout << getField(i, j) << " ";
            }
            else if (getField(i, j) == 42) {
                SetConsoleTextAttribute(color, 4);
                cout << getField(i, j) << " ";
            }
            else if (getField(i, j) == 35) {
                SetConsoleTextAttribute(color, 13);
                cout << getField(i, j) << " ";
            }
            else {
                SetConsoleTextAttribute(color, 7);
                cout << getField(i, j) << " ";
            }
        }
        cout << endl;
    }
    for (auto j = 0; j < FIELD_SIZE; ++j) {
        cout << "==";
    }
    cout << endl;
}

void Field::printMap() {
    HANDLE color = GetStdHandle(STD_OUTPUT_HANDLE);

    for (auto j = 0; j < FIELD_SIZE; ++j) {
        cout << "==";
    }
    cout << endl;
    for (auto i = 0; i < FIELD_SIZE; ++i) {
        for (auto j = 0; j < FIELD_SIZE; ++j) {
            //Print path of flying drones
            if (getMap(i, j) == 67) {
                setMap(i, j, '+');
                SetConsoleTextAttribute(color, 12);
                cout << getMap(i, j) << " ";
            }
            else if (getMap(i, j) == 85) {
                setMap(i, j, '+');
                SetConsoleTextAttribute(color, 11);
                cout << getMap(i, j) << " ";
            } 
            else if (getMap(i, j) == 61) {
                SetConsoleTextAttribute(color, 9);
                cout << getMap(i, j) << " ";
            }
            else if (getMap(i, j) == 118) {
                setMap(i, j, '+');
                SetConsoleTextAttribute(color, 2);
                cout << getMap(i, j) << " ";
            }
            else if (getMap(i, j) == 86) {
                setMap(i, j, '+');
                SetConsoleTextAttribute(color, 4);
                cout << getMap(i, j) << " ";
            }
            //Print path of falling drones
            else if (getMap(i, j) == '|' || getMap(i, j) == 42) {
                SetConsoleTextAttribute(color, 4);
                cout << getMap(i, j) << " ";
            }
            else {
                SetConsoleTextAttribute(color, 7);
                cout << getMap(i, j) << " ";
            }
        }
        cout << endl;
    }
    for (auto j = 0; j < FIELD_SIZE; ++j) {
        cout << "==";
    }
    cout << endl;
}

void Field::updateMap(Drone* hive[], Bomb* bombs, Charge* charge) {
    plantBombs(bombs);
    plantCharge(charge);

    for (auto i = 0; i < DRONES_NUM; ++i) {
        //Show path of falling drones
        if (hive[i]->getStatus() == 5 || hive[i]->getStatus() == 6) {
            setMap(hive[i]->getCurrentX(), hive[i]->getCurrentY(), '|');
        }
        //Show zero if drone lost battery charge
        else if (hive[i]->getStatus() == 4) {
            setMap(hive[i]->getCurrentX(), hive[i]->getCurrentY(), '0');
        }
        //Show cross if drone crashed
        else if (hive[i]->getStatus() == 7) {
            setMap(hive[i]->getCurrentX(), hive[i]->getCurrentY(), 'x');
        }
        else {
            setMap(hive[i]->getCurrentX(), hive[i]->getCurrentY(), droneType(hive[i], 0));
        }
        //Show huge cross if drone reached its destination
        if (hive[i]->getCurrentX() == 0) {
            setMap(hive[i]->getCurrentX(), hive[i]->getCurrentY(), 'X');
        }
    }
}

//Refreshing method checks all changes during simulation and refreshes field due to updated coordinates, also it checks drones and 
//objects collisions and updates map with a new data

void Field::refreshField(Drone* hive[], Bomb* bombs, Charge* charge, Cargo* cargo) {
    //Make field empty
    for (auto i = 0; i < FIELD_SIZE; ++i) {
        for (auto j = 0; j < FIELD_SIZE; ++j) {
            setField(i, j, FIELD_DOT);
        }
    }

    checkCollisions(hive, bombs, charge, cargo);
    updateMap(hive, bombs, charge);

    //Then set everything back with new data
    plantCharge(charge);
    plantBombs(bombs);
    plantCargo(cargo);

    //planting drones back
    for (auto i = 0; i < DRONES_NUM; ++i) {
        setField(hive[i]->getDestinationX(), hive[i]->getDestinationY(), 'o');
        if (hive[i]->getStatus() == 2 || hive[i]->getStatus() == 1 || hive[i]->getStatus() == 5) {
            setField(hive[i]->getCurrentX(), hive[i]->getCurrentY(), droneType(hive[i], 0));
        }
        else if (hive[i]->getStatus() == 7) {
            setField(hive[i]->getCurrentX(), hive[i]->getCurrentY(), 'x');
        }
        else if (hive[i]->getStatus() == 4) {
            setField(hive[i]->getCurrentX(), hive[i]->getCurrentY(), '0');
        }
        else if (hive[i]->getStatus() == 3) {
            setField(hive[i]->getCurrentX(), hive[i]->getCurrentY(), 'X');
        }
    }
}

void Field::plantBombs(Bomb* bombs) {
    for (auto i = 0; i < AMOUNT_OF_BOMBS; ++i) {
        if (bombs[i].getState()) {
            setField(bombs[i].getCurrentX(), bombs[i].getCurrentY(), 42);
        }
        //If bomb exploded before it has a new model
        else {
            setField(bombs[i].getCurrentX(), bombs[i].getCurrentY(), 46);
        }
    }
}

void Field::plantCharge(Charge* charge) {
    for (auto i = 0; i < AMOUNT_OF_CHARGE; ++i) {
        if (charge[i].getState()) {
            setField(charge[i].getCurrentX(), charge[i].getCurrentY(), 61);
        }
        //If battery charge been used before it disappears
        else {
            setField(charge[i].getCurrentX(), charge[i].getCurrentY(), ' ');
        }
    }
}

void Field::plantCargo(Cargo* cargo) {
    for (auto i = 0; i < AMOUNT_OF_CARGO; ++i) {
        if (cargo[i].getState()) {
            setField(cargo[i].getCurrentX(), cargo[i].getCurrentY(), 35);
        }
    }
}

//Main collisions check function checks if drones collide each other, if so it moves them lower, like they fell a bit
//if drones collided other objects - they change their state depending on objects they collided

void Field::checkCollisions(Drone* hive[], Bomb* bombs, Charge* charge, Cargo* cargo) {
    checkDroneCollisions(hive);
    checkBombCollisions(hive, bombs, cargo);
    checkChargeCollisions(hive, charge);
    checkCargoCollisions(hive, cargo);
}

void Field::checkDroneCollisions(Drone* hive[]) {
    for (auto i = 0; i < DRONES_NUM; ++i) {
        int flag = -1;

        for (auto j = 0; j < DRONES_NUM; ++j) {
            if (hive[j]->getCurrentY() == hive[i]->getCurrentY() && hive[j]->getCurrentX() == hive[i]->getCurrentX()) {
                flag++;
                //If drones have same coordinates and atleast one of them was "falling" then they both crash
                if (flag == 1) {
                    if (hive[i]->getStatus() == 5 || hive[j]->getStatus() == 5) {
                        hive[j]->setStatus(Crashed);
                        hive[i]->setStatus(Crashed);
                    }
                    //If they were flying, one of them will be set lower without loosing battery charge. 
                    //Consider they killed engines and fell for a second so the other drone can move freely
                    else {
                        if (isAvailable(hive[j]->getCurrentY(), hive[j]->getCurrentX() + 1)) {
                            hive[j]->setCurrentX(hive[j]->getCurrentX() + 1);
                        }
                        else {
                            hive[j]->setCurrentX(hive[j]->getCurrentX() + 2);
                        }
                    }
                }
            }
        }
    }
}

void Field::checkBombCollisions(Drone* hive[], Bomb* bombs, Cargo* cargo) {
    for (auto i = 0; i < DRONES_NUM; ++i) {
        for (auto j = 0; j < AMOUNT_OF_BOMBS; ++j) {
            //If drone collided bomb, bomb explodes no matter if drone was falling or flying
            //Flying drones can hit bombs too
            if (bombs[j].getCurrentY() == hive[i]->getCurrentY() && bombs[j].getCurrentX() == hive[i]->getCurrentX()) {
                if (bombs[j].getState() && (hive[i]->getStatus() == 2 || hive[i]->getStatus() == 5)) {
                    bombs[j].setState(false);

                    //But if drone was a Carrier type, it drops cargo
                    //Falling Carriers cannot drop cargo
                    if (hive[i]->getType() == "Carrier" && hive[i]->getStatus() == 2) {
                        Carrier* carry = dynamic_cast<Carrier*>(hive[i]);

                        for (auto k = 0; k < AMOUNT_OF_CARGO; ++k) {
                            if (cargo[k].getAmount() == 0) {
                                cargo[i].dropCargo(hive[i]->getCurrentX() + 1, hive[i]->getCurrentY(), carry->getCarryingCapacity());
                            }
                        }
                        //If carrier dropped cargo atleast once, it cant have it back
                        carry->setCarryingCapacity(carry->getCarryingCapacity()/2);
                    }
                    hive[i]->setStatus(Crashed);
                    hive[i]->setIsOnline(0);
                }
            }
        }
    }

    //Falling cargo can as well explode bombs
    for (auto i = 0; i < AMOUNT_OF_CARGO; ++i) {
        for (auto j = 0; j < AMOUNT_OF_BOMBS; ++j) {
            if (bombs[j].getCurrentY() == cargo[i].getCurrentY() && bombs[j].getCurrentX() == cargo[i].getCurrentX()) {
                if (cargo[i].getState() && bombs[j].getState()) {
                    //Only bomb explodes, cargo is going to keep falling down
                    bombs[j].setState(false);
                }
            }
        }
    }
}

void Field::checkChargeCollisions(Drone* hive[], Charge* charge) {
    for (auto i = 0; i < DRONES_NUM; ++i) {
        for (auto j = 0; j < AMOUNT_OF_CHARGE; ++j) {
            //If flying of falling drone collides battery charde point, it gains randomly generated amount of battery charge
            //If drone was falling its going back to online and get back to flying
            if (charge[j].getCurrentY() == hive[i]->getCurrentY() && charge[j].getCurrentX() == hive[i]->getCurrentX()) {
                if (charge[j].getState() && (hive[i]->getStatus() == 2 || hive[i]->getStatus() == 5)) {
                    hive[i]->setIsOnline(true);
                    hive[i]->setStatus(Flying);
                    hive[i]->setBatteryCharge(hive[i]->getBatteryCharge() + charge[j].getAmount());
                    charge[j].setState(false);
                }
            }
        }
    }
}

void Field::checkCargoCollisions(Drone* hive[], Cargo* cargo) {
    for (auto i = 0; i < DRONES_NUM; ++i) {
        for (auto j = 0; j < AMOUNT_OF_CARGO; ++j) {
            //Cargo can hit drones and make them crash
            if (cargo[j].getState() && cargo[j].getCurrentY() == hive[i]->getCurrentY() && cargo[j].getCurrentX() == hive[i]->getCurrentX()) {
                hive[i]->setBatteryCharge(hive[i]->getBatteryCharge() - cargo[j].getAmount());

                if (isAvailable(hive[i]->getCurrentY(), hive[i]->getCurrentX() + 1)) {
                    hive[i]->setCurrentX(hive[i]->getCurrentX() + 1);
                }

                //When cargo hits drone it disappears, consider its got shredded into pieces
                cargo[j].setAmount(0);
                cargo[j].setState(false);
            }
        }
    }
}

//Type method recieves parameter, depending on parameter it returns drone model for field or for map
//The second return is for updatring drone's path on the map
int Field::droneType(Drone* hive, int n) {
    if (hive->getType() == "Commander") {
        if (n == 0) {
            return 67;
        }
        else {
            return 12;
        }
    }
    else if (hive->getType() == "Communicator") {
        if (n == 0) {
            return 85;
        }
        else {
            return 11;
        }
    }
    else if (hive->getType() == "Carrier")
    {
        if (n == 0) {
            return 118;
        }
        else {
            return 2;
        }
    }
    else if (hive->getType() == "Navigator")
    {
        if (n == 0) {
            return 86;
        }
        else {
            return 14;
        }
    }
}

//Checks if atleast one of the drones in hive is still flying/falling to keep simulation going
//When all drones will gain "Fell" or "Reached" status - simulation will stop
bool Field::dronesInFlight(Drone* hive[]) {
    int flag = DRONES_NUM;
    for (auto i = 0; i < DRONES_NUM; ++i) {
        if (hive[i]->getStatus() == 3 || hive[i]->getStatus() == 6) {
            flag--;
        }
    }

    return flag > 0;
}