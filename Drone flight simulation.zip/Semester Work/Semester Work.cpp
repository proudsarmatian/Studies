﻿/*
Semester Work by Artem Kravchenko
Group: IN-92

Objective-oriented programming
"Drone's hive flight simulation"

Deadline 21.12.2020
Time spent: atleast 8 hours.

Borrowed functions: 
void setCursorPosition(int x, int y);

And this blocks:
HWND hWnd = GetConsoleWindow();
ShowWindow(hWnd, SW_SHOWMAXIMIZED);

This work is done by me peronally without any restricted help.

My simulation creates custom field with any amounts of bobms and battery charges possible, runs hive flight and prints results in the end.
*/

#include <iostream>
#include <time.h>
#include <windows.h>
#include <chrono>
#include <thread>

#include "Drone.h"
#include "Navigator.h"
#include "Commander.h"
#include "Carrier.h"
#include "Communicator.h"
#include "Field.h"
#include "Bomb.h"
#include "Charge.h"

using namespace std;

//Function that starts the sequence (spawns bots of th efield, gives them destination points, spawns additional objects on the field
void startSequence(Commander& data, Drone* hive[], Field& field, Bomb* bombs, Charge* charge);
//Spawns bombs on the field
void spawnBombs(Bomb * bombs, Field& field);
//Spawns battery charges on the field
void spawnCharge(Charge* charge, Field& field);
//Prints drones info
void printDrones(Drone* hive[]);
//Prints welcomind or ending screen
void printScreen(int n);
//Prints resulting text
void printResults(Drone* hive[], int n);

//Removes flickering
void setCursorPosition(int x, int y);

int main()
{
    //Accelerates in and out threads
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    srand(time(NULL));

    //Opens window in fullscren automatically
    HWND hWnd = GetConsoleWindow();
    ShowWindow(hWnd, SW_SHOWMAXIMIZED);

    //Creating field object and drones
    Field field;
    Commander com(1, VELOCITY, BATTERY_CHARGE, BATTERY_DISCHARGE, DESTINATION_X, 0, 0, 0, "GPS", "Straight");
    Communicator rad(2, VELOCITY, BATTERY_CHARGE, BATTERY_DISCHARGE, DESTINATION_X, 0, 0, 0, 5);
    Carrier c1(3, VELOCITY_CARRY, BATTERY_CHARGE_CARRY, BATTERY_DISCHARGE_CARRY, DESTINATION_X, 0, 0, 0, CARRY);
    Carrier c2(4, VELOCITY_CARRY, BATTERY_CHARGE_CARRY, BATTERY_DISCHARGE_CARRY, DESTINATION_X, 0, 0, 0, CARRY);

    //Initiating drones, bombs, battery charges and cargo arrays
    Drone* drones[DRONES_NUM] = { &com, &rad, &c1, &c2 };
    Bomb bombs[AMOUNT_OF_BOMBS];
    Charge charge[AMOUNT_OF_CHARGE];
    Cargo cargo[AMOUNT_OF_CARGO];

    int stage = 0;

    //Prints welcoming screen
    printScreen(0);
    //Requirement to press any button to proceed
    system("pause");
    //Cleares the screen
    system("cls");

    startSequence(com, drones, field, bombs, charge);
    system("pause");
    system("cls");

    //Main simulation loop
    while (field.dronesInFlight(drones)) {
        stage++;
        for (auto i = 0; i < DRONES_NUM; ++i) {
            drones[i]->move();
        }

        //Additional loop for cargo fall if theres any
        for (auto i = 0; i < AMOUNT_OF_CARGO; ++i) {
            cargo[i].fall();
        }

        //Field refreshing and printing drones info
        field.refreshField(drones, bombs, charge, cargo);
        field.print();
        printDrones(drones);
        cout << "Stage # " << stage << endl;

        setCursorPosition(0, 0);

        //Controls time of screen update
        this_thread::sleep_for(chrono::seconds(0));
        
    }

    system("cls");

    //Prints ending screen
    printScreen(1);

    system("pause");
    system("cls");
    printResults(drones, stage);

    //Prints resulting map
    field.printMap();

    return 0;
}

//Main sequence function
void startSequence(Commander& data, Drone* hive[], Field& field, Bomb* bombs, Charge* charge) {
    HANDLE color = GetStdHandle(STD_OUTPUT_HANDLE);

    //Checking if field fits the requirements
    field.check();

    spawnBombs(bombs, field);
    spawnCharge(charge, field);

    //Generating spawn points for drones with Commander's help
    for (auto i = 0; i < DRONES_NUM; ++i) {
        hive[i]->setCurrentX(FIELD_SIZE - 1);
        int flag = 0;

        //loop works till it finds any availaple point
        while (flag == 0) {
            int n = data.generate();

            if (field.isAvailable(FIELD_SIZE - 1, n)) {
                hive[i]->setCurrentY(n);
                field.setField(FIELD_SIZE - 1, n, field.droneType(hive[i], 0));
                field.setMap(FIELD_SIZE - 1, n, field.droneType(hive[i], 0));
                flag++;
            }
        }

        //Generating destination points for drones with Commander's help
        hive[i]->setDestinationX(DESTINATION_X);
        int flag2 = 0;

        //Same
        while (flag2 == 0) {
            int n = data.generate();

            if (field.isAvailable(DESTINATION_X, n)) {
                hive[i]->setDestinationY(n);
                field.setField(DESTINATION_X, n, 'o');
                field.setMap(DESTINATION_X, n, 'X');
                flag2++;
            }
        }
    }

    field.print();
    printDrones(hive);

    //Sets color attributes
    SetConsoleTextAttribute(color, 12);
    cout << "          [PRESS ENTER TO START SEQUENCE!]" << endl;
    SetConsoleTextAttribute(color, 7);
}

void spawnBombs(Bomb* bombs, Field& field) {
    //Generates bombs coordinates pretty much like drones are spawning
    for (auto i = 0; i < AMOUNT_OF_BOMBS; ++i) {
        int flag = 0;

        while (flag == 0) {
            int n = bombs[i].generate();
            int m = bombs[i].generate();

            if (field.isAvailable(n, m)) {
                bombs[i].setCurrentY(n);
                bombs[i].setCurrentX(m);
                field.setField(m, n, 42);
                field.setMap(m, n, 42);
                flag++;
            }
        }
    }
}

void spawnCharge(Charge* charge, Field& field) {
    //Generates bombs coordinates pretty much like drones are spawning
    for (auto i = 0; i < AMOUNT_OF_CHARGE; ++i) {
        int flag = 0;

        while (flag == 0) {
            int n = charge[i].generate();
            int m = charge[i].generate();

            if (field.isAvailable(n, m)) {
                charge[i].setCurrentY(n);
                charge[i].setCurrentX(m);
                charge[i].generateAmount();

                field.setField(m, n, 61);
                field.setMap(m, n, 61);
                flag++;
            }
        }
    }
}

//Print drones info
void printDrones(Drone* hive[]) {
    for (auto i = 0; i < DRONES_NUM; ++i) {
        hive[i]->info();
    }
}

void printResults(Drone* hive[], int n) {
    HANDLE color = GetStdHandle(STD_OUTPUT_HANDLE);

    //Outcomes
    for (auto i = 0; i < DRONES_NUM; ++i) {
        SetConsoleTextAttribute(color, 2);
        cout << hive[i]->getType();
        SetConsoleTextAttribute(color, 7);
        cout << " drone #" << hive[i]->getId() << " ended up with battery charge at " << hive[i]->getBatteryCharge() << endl;

        SetConsoleTextAttribute(color, 3);
        cout << "Status: ";
        SetConsoleTextAttribute(color, 7);

        cout << hive[i]->printStatus() << endl;

        //Checks if Carrier drones delievered cargo
        if (hive[i]->getType() == "Carrier") {
            Carrier* carry = dynamic_cast<Carrier*>(hive[i]);
            if (carry->getCarryingCapacity() == 0 || carry->getStatus() == Fell) {
                SetConsoleTextAttribute(color, 12);
                cout << '0';
            }
            else if ((carry->getCarryingCapacity() > 0 && carry->getCarryingCapacity() <= (CARRY / 2)) && carry->getStatus() == Reached) {
                SetConsoleTextAttribute(color, 14);
                cout << carry->getCarryingCapacity();
            }
            else if ((carry->getCarryingCapacity() > (CARRY / 2)) && carry->getStatus() == Reached){
                SetConsoleTextAttribute(color, 10);
                cout << carry->getCarryingCapacity();
            }

            SetConsoleTextAttribute(color, 7);
            cout << " lbs of cargo delivered.";
            if ((carry->getCarryingCapacity() > (CARRY / 2)) && carry->getStatus() == Reached) {
                SetConsoleTextAttribute(color, 10);
                cout << " Great job!" << endl;
                SetConsoleTextAttribute(color, 7);
            }
            else {
                cout << endl;
            }
        }
        SetConsoleTextAttribute(color, 0);
        cout << "---------------------------------" << endl;
        SetConsoleTextAttribute(color, 7);
    }
    if (n <= 10) {
        cout << "Simulation took only " << n << " stages. It was a massacre... Almost like old days in 'nam..." << endl;
    }
    else if (n > 10 && n <= 20) {
        cout << "Simulation took only " << n << " stages. Wow, that's a short one." << endl;
    }
    else if (n > 20 && n <= 40) {
        cout << "Simulation took " << n << " stages." << endl;
    }
    else if (n > 40 && n <= 60) {
        cout << "Simulation took " << n << " stages. That was an adventure, for sure." << endl;
    }
    else if (n > 60 && n <= 100) {
        cout << "Simulation took " << n << " stages. Tankred endures!" << endl;
    }
    else if (n > 100) {
        cout << "Simulation took " << n << " stages..." << endl;
        SetConsoleTextAttribute(color, 14);
        cout << "I vosstali mashini is pepla yedernogo ognya i poshla voina na unichtozhenie..." << endl;
        SetConsoleTextAttribute(color, 7);
    }
}

void printScreen(int n) {
    HANDLE color = GetStdHandle(STD_OUTPUT_HANDLE);

    if (n == 0) {
        cout << "          Welcome to my drone hive flight simulator!" << endl << endl;
        SetConsoleTextAttribute(color, 14);
        cout <<
            "        eeeee e   e eeeee e     e        e   e  e eeee \n"
            "        8     8   8 8   8 8     8        8   8  8 8     \n"
            "        8eeee 8eee8 8eee8 8e    8e       8e  8  8 8eee \n"
            "           88 88  8 88  8 88    88       88  8  8 88   \n"
            "        8ee88 88  8 88  8 88eee 88eee    88ee8ee8 88ee \n"
            "                                                       \n";
        SetConsoleTextAttribute(color, 12);
        cout <<
            "  sSSs  sdSS_SSSSSSbs   .S_SSSs     .S_sSSs    sdSS_SSSSSSbs  \n"
            " d%%SP  YSSS~S%SSSSSP  .SS~SSSSS   .SS~YS%%b   YSSS~S%SSSSSP  6MMMb  \n"
            "d%S'         S%S       S%S   SSSS  S%S   `S%b       S%S      6M' `Mb  \n"
            "S%|          S%S       S%S    S%S  S%S    S%S       S%S      `'   MM \n"
            "S&S          S&S       S%S SSSS%S  S%S    d*S       S&S           MM  \n"
            "Y&Ss         S&S       S&S  SSS%S  S&S   .S*S       S&S          ,M9\n"
            "`S&&S        S&S       S&S    S&S  S&S_sdSSS        S&S         MM9  \n"
            "  `S*S       S&S       S&S    S&S  S&S~YSY%b        S&S         M    \n"
            "   l*S       S*S       S*S    S&S  S*S   `S%b       S*S              \n"
            "  .S*P       S*S       S*S    S*S  S*S    S%S       S*S        68b    \n"
            "sSS*S        S*S       S*S    S*S  S*S    S&S       S*S        Y8   \n"
            "YSS'         S*S       SSS    S*S  S*S    SSS       S*S        Y    \n"
            "             SP               SP   SP               SP        \n"
            "             Y                Y    Y                Y         \n";
        SetConsoleTextAttribute(color, 7);
    }
    else if (n == 1) {
        SetConsoleTextAttribute(color, 9);
        cout <<

            "sdSS_SSSSSSbs   .S    S.     sSSs          sSSs   .S_sSSs     .S_sSSs    \n"
            "YSSS~S%SSSSSP  .SS    SS.   d%%SP         d%%SP  .SS~YS%%b   .SS~YS%%b   \n"
            "     S%S       S%S    S%S  d%S'          d%S'    S%S   `S%b  S%S   `S%b  \n"
            "     S%S       S%S    S%S  S%S           S%S     S%S    S%S  S%S    S%S  \n"
            "     S&S       S%S SSSS%S  S&S           S&S     S%S    S&S  S%S    S&S  \n"
            "     S&S       S&S  SSS&S  S&S_Ss        S&S_Ss  S&S    S&S  S&S    S&S  \n"
            "     S&S       S&S    S&S  S&S~SP        S&S~SP  S&S    S&S  S&S    S&S  \n"
            "     S&S       S&S    S&S  S&S           S&S     S&S    S&S  S&S    S&S  \n"
            "     S*S       S*S    S*S  S*b           S*b     S*S    S*S  S*S    d*S  \n"
            "     S*S       S*S    S*S  S*S.          S*S.    S*S    S*S  S*S   .S*S  \n"
            "     S*S       S*S    S*S   SSSbs         SSSbs  S*S    S*S  S*S_sdSSS   \n"
            "     S*S       SSS    S*S    YSSP          YSSP  S*S    SSS  SSS~YSSY    \n"
            "     SP               SP                         SP                      \n"
            "     Y                Y                          Y                       \n"
            "                                                                         \n";
        SetConsoleTextAttribute(color, 12);
        cout << "          [PRESS ENTER TO SEE RESULTS AND MAP]" << endl;
        SetConsoleTextAttribute(color, 7);
    }
}

//Console flickering solution
void setCursorPosition(int x, int y)
{
    static const HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    cout.flush();
    COORD coord = { (SHORT)x, (SHORT)y };
    SetConsoleCursorPosition(hOut, coord);
}