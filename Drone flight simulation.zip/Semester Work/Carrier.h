#ifndef CARRIER_H
#define CARRIER_H
#include "Drone.h"

class Carrier :
    public Drone
{
private:
    int carryingCapacity;
public:
    Carrier(int id, int velocity, int batteryCharge, int batteryDischarge, int currentX, int currentY, int destinationX, int destinationY, int carryingCapacity);

    //Getters and Setters
    int getCarryingCapacity() const;
    void setCarryingCapacity(int carryingCapacity);

    //Main methods
    void info()override;
};

#endif